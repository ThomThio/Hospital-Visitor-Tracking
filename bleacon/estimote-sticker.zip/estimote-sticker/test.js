var EstimoteSticker = require('./estimote-sticker');

EstimoteSticker.on('discover', function(estimoteSticker) {
	macs = ["fb:f8:e7:ea:bf:81"]
	ids = ["dcccf79c84d77521","43fb737941fcc163"]
	// console.log(estimoteSticker);

	// if (estimoteSticker.moving === true) {
	// 	console.log(estimoteSticker.id);
	// }

	if (estimoteSticker.id === ids[0] || estimoteSticker.id === ids[1]){
		if(estimoteSticker.moving === true) {
			console.log("moving match found");
	  		console.log(estimoteSticker.id);
	  		console.log(estimoteSticker.moving);
	  		console.log(estimoteSticker.acceleration);
	  		console.log(estimoteSticker.currentMotionStateDuration);
	  		console.log(estimoteSticker.previousMotionStateDuration);
	  		console.log("\n")
			
		}
	}
});

EstimoteSticker.startScanning();

// currentMotionStateDuration - #previousMotionStateDuration
// acceleration